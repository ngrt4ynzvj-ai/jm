TESORO LOUNGE EMAIL SIGNATURE — HOSTING ASSETS

All files are individual transparent PNG images ready to upload and host.

Brand colour:
#008073

Files:
- tesoro-logo.png
- email.png
- phone.png
- location.png
- website.png
- facebook.png
- instagram.png

After uploading them to a permanent public HTTPS location, provide the seven direct image URLs so the final HTML signature can be updated.

Recommended:
- Keep the filenames unchanged.
- Ensure each URL opens the raw PNG directly.
- Do not use links that require sign-in or redirect to a preview page.
- Use permanent HTTPS URLs.
